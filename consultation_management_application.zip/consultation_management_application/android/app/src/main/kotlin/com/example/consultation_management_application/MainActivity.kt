package com.example.consultation_management_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
