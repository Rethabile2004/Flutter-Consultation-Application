//
// Coder                    : Rethabile Eric Siase
// Time taken to complete   : 2 days 
// Number of external help  : 0
// Purpose                  : To help users manage their consultation appointments
//

// application model class
class Consultation {
   String date, time, description, topic;
   Consultation({
    required this.date,
    required this.time,
    required this.description,
    required this.topic,
  });
}
